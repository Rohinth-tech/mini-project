 <html>
<head>
<title>Food order website</title>
<link rel="stylesheet"href="admin1.css">
</head>
<body>
<div class="menu">
<center>
<div class="wrapper">
    <ul>
       <li><a href="index.php">Home</a></li>
<li><a href="manageadmin.php">Admin</a></li>
<li><a href="manage-category.php">Category</a></li>
<li><a href="manage-category.php">Food</a></li>
<li><a href="manage-order.php">order</a></li>
    </div>
</center>
</div>