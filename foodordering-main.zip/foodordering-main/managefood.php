<html>
<head>
<title>Food order website</title>
<link rel="stylesheet"href="admin1.css">
</head>
<body>
<div class="menu">
<center>
<div class="wrapper">
    <ul>
       <li><a href="index.php">Home</a></li>
<li><a href="manageadmin.php">Admin</a></li>
<li><a href="manage-category.php">Category</a></li>
<li><a href="managefood.php">Food</a></li>
<li><a href="manage-order.php">order</a></li>
    </div>
</center>
</div>
<div class="main-content">
 <div class="wrapper">
 <h1>Manage food</h1>

<br />
<a href="#" class="btn-primary">ADD FOOD</a>
<br>
<br>

<a href="#" class="btn-primary1">update food</a>
<a href="#" class="btn-primary2">Delete food</a>
  
</td>
</tr>
   </div>


</body></html>

