<html>
<head>
<title>Food order website</title>
<link rel="stylesheet"href="admin1.css">
</head>
<body>
<div class="menu">
<center>
<div class="wrapper">
    <ul>
       <li><a href="index.php">Home</a></li>
<li><a href="manageadmin.php">Admin</a></li>
<li><a href="manage-category.php">Category</a></li>
<li><a href="managefood.php">Food</a></li>
<li><a href="manage-order.php">order</a></li>
    </div>
</center>
</div>
<div class="main-content">
 <div class="wrapper">
 <h1>Manage category</h1>
<br />
<a href="#" class="btn-primary">ADD CATEGORY</a>
<br /><br />
<table class="s">
<tr>
<th>S.N</th>
<th>full name</th>
<th>username</th>
<th>Actions</th>
</tr>
<tr>
<td>1.</td>
<td>Rohisow sai</td>
<td>Rohisowsai</td>
<td>
<a href="#" class="btn-primary1">update Admin</a>
<a href="#" class="btn-primary2">Delete Admin</a>
  
</td>
</tr>
   </div>


</body></html>

